/* Horizon Tab — background service worker.
   Single job: register/unregister the optional Prompt Bridge content
   script for the AI chat sites that ignore URL prefill (Gemini,
   DeepSeek). The bridge is registered only while BOTH the setting is on
   AND the user has granted that specific origin. Nothing else runs. */

const BRIDGE_SCRIPT_ID = "hz-ai-bridge";
const BRIDGE_ORIGINS = [
  "https://gemini.google.com/*",
  "https://chat.deepseek.com/*",
];

async function grantedBridgeOrigins() {
  const granted = [];
  for (const o of BRIDGE_ORIGINS) {
    try { if (await chrome.permissions.contains({ origins: [o] })) granted.push(o); }
    catch (e) { /* skip */ }
  }
  return granted;
}

async function syncBridgeRegistration() {
  if (!chrome.scripting || !chrome.scripting.registerContentScripts) return;

  let enabled = false;
  try {
    const r = await chrome.storage.sync.get(["hz"]);
    enabled = !!(r && r.hz && r.hz.aiBridge);
  } catch (e) { /* default off */ }

  const origins = enabled ? await grantedBridgeOrigins() : [];
  let existing = [];
  try { existing = await chrome.scripting.getRegisteredContentScripts({ ids: [BRIDGE_SCRIPT_ID] }); }
  catch (e) { existing = []; }
  const have = existing && existing.length ? existing[0] : null;

  try {
    if (!origins.length) {
      if (have) await chrome.scripting.unregisterContentScripts({ ids: [BRIDGE_SCRIPT_ID] });
      return;
    }
    const spec = {
      id: BRIDGE_SCRIPT_ID,
      js: ["ai-bridge.js"],
      matches: origins,
      runAt: "document_idle",
      persistAcrossSessions: true,
    };
    const same = have && have.matches && have.matches.length === origins.length &&
                 origins.every((o) => have.matches.includes(o));
    if (same) return;
    if (have) await chrome.scripting.updateContentScripts([spec]);
    else await chrome.scripting.registerContentScripts([spec]);
  } catch (err) {
    console.error("[Horizon] bridge registration failed:", err);
  }
}

chrome.runtime.onInstalled.addListener(syncBridgeRegistration);
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(syncBridgeRegistration);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && changes.hz) syncBridgeRegistration();
});
if (chrome.permissions && chrome.permissions.onAdded) chrome.permissions.onAdded.addListener(syncBridgeRegistration);
if (chrome.permissions && chrome.permissions.onRemoved) chrome.permissions.onRemoved.addListener(syncBridgeRegistration);
syncBridgeRegistration();
