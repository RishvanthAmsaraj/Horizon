# Horizon Tab

A minimal, beautiful, customizable new tab page. Your horizon, your way.

Horizon replaces Chrome's default new tab with a fast, private dashboard — a clock, weather, and a search bar that fans out into a drawer of engines, AI chats, and store search. Every source is yours to curate.

## Features

- **Unified search drawer** — one box that searches the web, chats an AI, or shops a store. Switch with a click, tab, or arrow key.
  - **8 search engines** — Google, DuckDuckGo, Brave, Bing, Startpage, Kagi, Qwant, SearXNG.
  - **6 AI providers** — Perplexity, ChatGPT, Claude, Grok, Gemini, DeepSeek (with an opt-in Prompt Bridge for providers that ignore URL prefill).
  - **14 stores** — Amazon, eBay, Walmart, Target, Best Buy, Costco, Home Depot, Lowe's, Etsy, Newegg, B&H, IKEA, Wayfair, AliExpress.
- **Your sources, your way** — hide any built-in source you don't use, and add your own search engine, AI, or store with a `%s` search template.
- **Two-axis filters** — verticals (All / News / Images / Video) × refiners (Reddit, Academic, PDF, Exact, Recent), freely combinable, plus an AI-Free toggle on engines that inject AI answers.
- **Bangs** — start a query with `!yt`, `!a`, `!w`, `!gpt`, `!news` and more to retarget that single search.
- **Themes** — Slate, Ivory, Navy, Modern (auto day/night), and a fully custom color theme.
- **Custom background** — upload any image; auto-contrast dimming and optional blur.
- **Quick links** — your own row of shortcuts, editable inline.
- **Weather** — local forecast from the National Weather Service (US), cached so ten tabs cost one request.
- **Prompt Bridge (optional)** — Gemini and DeepSeek ignore prefilled links, so a search there opens an empty chat. With the bridge on, Horizon types your query into the box for you.

## Privacy

Horizon is local-first. There are no accounts, no analytics, and no tracking. Your settings and background sync through Chrome's own `storage.sync`. The only network calls are the ones you trigger (a search) or explicitly opt into (weather, the prompt bridge).

## Install (development)

1. Clone or download this repository.
2. Open `chrome://extensions`.
3. Enable **Developer mode** (top right).
4. Click **Load unpacked** and select this folder.
5. Open a new tab.

## Permissions

- `storage` — save your settings and background.
- `scripting` — register the optional prompt bridge only when you turn it on.
- Optional host permissions (requested at runtime, never granted silently):
  - `gemini.google.com`, `chat.deepseek.com` — only if you enable the prompt bridge.

## Contributing

Horizon is open source. The search source tables (`SE`, `AI`, `SHOP`, `BANGS`) are plain objects in `tab.js` — adding a new engine, provider, store, or bang is usually a one-line change.

## License

[MIT](LICENSE)
