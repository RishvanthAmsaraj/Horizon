# Privacy Policy — Horizon Tab

**Last updated:** September 2026

Horizon Tab is a local-first browser extension. It does **not** collect, store, or transmit any personal data to the developer, and it has no accounts, no analytics, and no advertising or tracking SDKs.

## What the extension stores

All of your settings — theme, quick links, custom search sources, background image — are stored **locally in your browser** via Chrome's `chrome.storage` API (and sync between your own devices through Chrome Sync, if you have it enabled). None of it is sent to any Horizon server, because there is no Horizon server.

## Network requests the extension makes

Horizon makes a small number of network requests only to power specific features. None of them are sent to the developer.

| Feature | Destination | What is sent |
|---|---|---|
| Weather | `api.weather.gov` (US National Weather Service) | Your configured coordinates (or the default location) to fetch the local forecast. US coverage only. |
| Quick-link favicons | `google.com/s2/favicons` | The domain of a quick link, to fetch its icon. |
| Searches, AI chats, store search | the service you pick (Google, Amazon, etc.) | Whatever you type into the search box. These are normal navigations you initiate, identical to typing the query on the site directly. |

## Data that never leaves your device

- The **Prompt Bridge** reads only the query you just typed, to paste it into the chat box on Gemini or DeepSeek — it never reads your conversation or anything else.

## Contact

For privacy questions, open an issue on the project's repository or contact the developer.
